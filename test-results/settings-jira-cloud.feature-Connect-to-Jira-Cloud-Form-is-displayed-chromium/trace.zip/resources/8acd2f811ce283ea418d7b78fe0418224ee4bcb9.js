"use strict";
(self["webpackChunkvelocap"] = self["webpackChunkvelocap"] || []).push([["main"],{

/***/ 9211:
/*!***********************************************!*\
  !*** ./apps/velocap/src/app/app.component.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _shared_services_side_nav_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shared/services/side-nav.service */ 9146);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/layout */ 9743);
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/sidenav */ 1465);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _layout_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./layout/header/header.component */ 3810);
/* harmony import */ var _layout_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./layout/sidebar/sidebar.component */ 381);











const _c0 = ["sidenav"];
class AppComponent {
  constructor(observer, sideNavService) {
    this.observer = observer;
    this.sideNavService = sideNavService;
    this.mobile = true;
  }
  ngOnInit() {
    var _this = this;
    this.observer.observe(['(max-width: 800px)']).subscribe(screenSize => {
      this.mobile = screenSize.matches;
    });
    this.sideNavService.toggleBehaviour.subscribe( /*#__PURE__*/(0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.sidenav && (yield _this.sidenav.toggle());
    }));
  }
  static #_ = this.ɵfac = function AppComponent_Factory(t) {
    return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_5__.BreakpointObserver), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_shared_services_side_nav_service__WEBPACK_IMPORTED_MODULE_1__.SideNavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: AppComponent,
    selectors: [["velocap-app"]],
    viewQuery: function AppComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.sidenav = _t.first);
      }
    },
    decls: 7,
    vars: 2,
    consts: [["autosize", ""], [3, "mode", "opened"], ["sidenav", ""]],
    template: function AppComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "velocap-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "mat-sidenav-container", 0)(2, "mat-sidenav", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "velocap-sidebar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "mat-sidenav-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("mode", ctx.mobile ? "over" : "side")("opened", !ctx.mobile);
      }
    },
    dependencies: [_angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenav, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavContainer, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_6__.MatSidenavContent, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterOutlet, _layout_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, _layout_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_3__.SidebarComponent],
    styles: ["h1[_ngcontent-%COMP%] {\n  padding: 0 1rem;\n}\n\nh2[_ngcontent-%COMP%] {\n  padding: 1rem;\n}\n\nmat-sidenav-container[_ngcontent-%COMP%] {\n  height: 100%;\n}\n\nmat-sidenav[_ngcontent-%COMP%] {\n  padding-top: 3.5rem;\n}\n@media screen and (min-width: 600px) {\n  mat-sidenav[_ngcontent-%COMP%] {\n    padding-top: 4rem;\n  }\n}\n\nmat-sidenav-content[_ngcontent-%COMP%] {\n  padding-top: 3.5rem;\n}\n@media screen and (min-width: 600px) {\n  mat-sidenav-content[_ngcontent-%COMP%] {\n    padding-top: 4rem;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvdmVsb2NhcC9zcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7QUFDRjs7QUFFQTtFQUFJLGFBQUE7QUFFSjs7QUFBQTtFQUNFLFlBQUE7QUFHRjs7QUFDQTtFQUNFLG1CQUFBO0FBRUY7QUFERTtFQUZGO0lBR0ksaUJBQUE7RUFJRjtBQUNGOztBQUFBO0VBQ0UsbUJBQUE7QUFHRjtBQUZFO0VBRkY7SUFHSSxpQkFBQTtFQUtGO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJoMSB7XG4gIHBhZGRpbmc6IDAgMXJlbTtcbn1cblxuaDIge3BhZGRpbmc6IDFyZW07fVxuXG5tYXQtc2lkZW5hdi1jb250YWluZXIge1xuICBoZWlnaHQ6MTAwJTtcbn1cblxuLy8gTW92ZSB0aGUgY29udGVudCBkb3duIHNvIHRoYXQgaXQgd29uJ3QgYmUgaGlkZGVuIGJ5IHRoZSB0b29sYmFyXG5tYXQtc2lkZW5hdiB7XG4gIHBhZGRpbmctdG9wOiAzLjVyZW07XG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDYwMHB4KSB7XG4gICAgcGFkZGluZy10b3A6IDRyZW07XG4gIH1cbn1cblxuLy8gTW92ZSB0aGUgY29udGVudCBkb3duIHNvIHRoYXQgaXQgd29uJ3QgYmUgaGlkZGVuIGJ5IHRoZSB0b29sYmFyXG5tYXQtc2lkZW5hdi1jb250ZW50e1xuICBwYWRkaW5nLXRvcDogMy41cmVtO1xuICBAbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiA2MDBweCkge1xuICAgIHBhZGRpbmctdG9wOiA0cmVtO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 3760:
/*!********************************************!*\
  !*** ./apps/velocap/src/app/app.module.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/platform-browser/animations */ 4987);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/toolbar */ 2484);
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/sidenav */ 1465);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/button */ 895);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/list */ 3228);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 9211);
/* harmony import */ var _layout_header_header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./layout/header/header.component */ 3810);
/* harmony import */ var _layout_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./layout/sidebar/sidebar.component */ 381);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _app_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.routes */ 3834);
/* harmony import */ var _shared_services_side_nav_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shared/services/side-nav.service */ 9146);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/select */ 6355);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common/http */ 4860);
/* harmony import */ var _modules_theme_theme_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modules/theme/theme.module */ 3079);
/* harmony import */ var _modules_alert_notification_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modules/alert/notification.module */ 8049);
/* harmony import */ var _features_settings_settings_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./features/settings/settings.component */ 7380);
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/tabs */ 989);
/* harmony import */ var _features_settings_jira_jira_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./features/settings/jira/jira.component */ 5155);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/input */ 26);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material/card */ 8497);
/* harmony import */ var _shared_components_custom_banner_custom_banner_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./shared/components/custom-banner/custom-banner.component */ 1578);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/material/tooltip */ 702);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 1699);




























class AppModule {
  static #_ = this.ɵfac = function AppModule_Factory(t) {
    return new (t || AppModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineNgModule"]({
    type: AppModule,
    bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent]
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjector"]({
    providers: [_shared_services_side_nav_service__WEBPACK_IMPORTED_MODULE_4__.SideNavService],
    imports: [_modules_alert_notification_module__WEBPACK_IMPORTED_MODULE_6__.NotificationModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__.BrowserModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__.BrowserAnimationsModule, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_13__.MatToolbarModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_14__.MatSidenavModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_15__.MatButtonModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_16__.MatIconModule, _angular_material_list__WEBPACK_IMPORTED_MODULE_17__.MatListModule, _angular_router__WEBPACK_IMPORTED_MODULE_18__.RouterModule.forRoot(_app_routes__WEBPACK_IMPORTED_MODULE_3__.appRoutes), _angular_material_select__WEBPACK_IMPORTED_MODULE_19__.MatSelectModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_20__.HttpClientModule, _modules_theme_theme_module__WEBPACK_IMPORTED_MODULE_5__.ThemeModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_21__.MatTabsModule, _angular_material_input__WEBPACK_IMPORTED_MODULE_22__.MatInputModule, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.ReactiveFormsModule, _angular_material_card__WEBPACK_IMPORTED_MODULE_24__.MatCardModule, _shared_components_custom_banner_custom_banner_component__WEBPACK_IMPORTED_MODULE_9__.CustomBannerComponent, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_25__.MatTooltipModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_layout_header_header_component__WEBPACK_IMPORTED_MODULE_1__.HeaderComponent, _layout_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_2__.SidebarComponent, _app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent, _features_settings_settings_component__WEBPACK_IMPORTED_MODULE_7__.SettingsComponent, _features_settings_jira_jira_component__WEBPACK_IMPORTED_MODULE_8__.JiraComponent],
    imports: [_modules_alert_notification_module__WEBPACK_IMPORTED_MODULE_6__.NotificationModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__.BrowserModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__.BrowserAnimationsModule, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_13__.MatToolbarModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_14__.MatSidenavModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_15__.MatButtonModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_16__.MatIconModule, _angular_material_list__WEBPACK_IMPORTED_MODULE_17__.MatListModule, _angular_router__WEBPACK_IMPORTED_MODULE_18__.RouterModule, _angular_material_select__WEBPACK_IMPORTED_MODULE_19__.MatSelectModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_20__.HttpClientModule, _modules_theme_theme_module__WEBPACK_IMPORTED_MODULE_5__.ThemeModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_21__.MatTabsModule, _angular_material_input__WEBPACK_IMPORTED_MODULE_22__.MatInputModule, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.ReactiveFormsModule, _angular_material_card__WEBPACK_IMPORTED_MODULE_24__.MatCardModule, _shared_components_custom_banner_custom_banner_component__WEBPACK_IMPORTED_MODULE_9__.CustomBannerComponent, _angular_common__WEBPACK_IMPORTED_MODULE_26__.NgOptimizedImage, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_25__.MatTooltipModule]
  });
})();

/***/ }),

/***/ 3834:
/*!********************************************!*\
  !*** ./apps/velocap/src/app/app.routes.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   appRoutes: () => (/* binding */ appRoutes)
/* harmony export */ });
/* harmony import */ var _features_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./features/dashboard/dashboard.component */ 1950);
/* harmony import */ var _features_settings_settings_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./features/settings/settings.component */ 7380);


const appRoutes = [{
  path: '',
  component: _features_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent
}, {
  path: 'settings',
  component: _features_settings_settings_component__WEBPACK_IMPORTED_MODULE_1__.SettingsComponent
}];

/***/ }),

/***/ 1950:
/*!************************************************************************!*\
  !*** ./apps/velocap/src/app/features/dashboard/dashboard.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DashboardComponent: () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);


class DashboardComponent {
  constructor() {}
  static #_ = this.ɵfac = function DashboardComponent_Factory(t) {
    return new (t || DashboardComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DashboardComponent,
    selectors: [["velocap-dashboard"]],
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵStandaloneFeature"]],
    decls: 2,
    vars: 0,
    template: function DashboardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "dashboard works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 5155:
/*!***********************************************************************!*\
  !*** ./apps/velocap/src/app/features/settings/jira/jira.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JiraComponent: () => (/* binding */ JiraComponent)
/* harmony export */ });
/* harmony import */ var _Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _shared_validators_url__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/validators/url */ 7508);
/* harmony import */ var _shared_services_http_setting_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/services/http/setting.service */ 7904);
/* harmony import */ var _modules_alert_services_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../modules/alert/services/notification.service */ 7751);
/* harmony import */ var _shared_services_http_jira_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/services/http/jira.service */ 1758);
/* harmony import */ var _shared_services_http_jira_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/http/jira-project.service */ 9795);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 1236);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/button */ 895);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/form-field */ 1333);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/select */ 6355);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/core */ 5309);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/input */ 26);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/card */ 8497);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/tooltip */ 702);
























function JiraComponent_img_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "img", 17);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("ngSrc", ctx_r0.getSelectedProjectParam("avatarUrl"));
  }
}
function JiraComponent_mat_option_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "mat-option", 18)(1, "mat-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "img", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const project_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", project_r2.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("ngSrc", project_r2.avatarUrl);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate2"]("", project_r2.jiraKey, " - ", project_r2.name, "");
  }
}
class JiraComponent {
  constructor(formBuilder, settingService, jiraService, jiraProjectService, notificationService) {
    this.formBuilder = formBuilder;
    this.settingService = settingService;
    this.jiraService = jiraService;
    this.jiraProjectService = jiraProjectService;
    this.notificationService = notificationService;
    this.hideToken = true;
    this.formGroup = this.formBuilder.group({
      jiraUrl: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _shared_validators_url__WEBPACK_IMPORTED_MODULE_1__.UrlValidator.validate]],
      jiraToken: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      jiraEmail: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.email]],
      jiraProject: [0]
    });
    this.connectionStatus = false;
    this.jiraProjects = [];
  }
  ngOnInit() {
    var _this = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.getProjects();
      yield _this.populateSettings();
      _this.formGroup.get('jiraProject')?.disable();
    })();
  }
  getProjects() {
    var _this2 = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.jiraProjects = (yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this2.jiraProjectService.getProjects())).data;
    })();
  }
  populateSettings() {
    var _this3 = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      (yield _this3.fetchSettings()).forEach(setting => _this3.setFormValue(setting));
    })();
  }
  fetchSettings() {
    var _this4 = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return (yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this4.settingService.getByKeys(['jiraUrl', 'jiraToken', 'jiraEmail', 'jiraProject'])))[0];
    })();
  }
  setFormValue(setting) {
    const control = this.formGroup.controls[setting.key];
    control && control.setValue(setting.key === 'jiraProject' ? +setting.value : setting.value);
  }
  onSubmit() {
    var _this5 = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5.settingService.updateByKeys([{
        key: 'jiraUrl',
        value: _this5.formGroup.controls.jiraUrl.value || ''
      }, {
        key: 'jiraToken',
        value: _this5.formGroup.controls.jiraToken.value || ''
      }, {
        key: 'jiraEmail',
        value: _this5.formGroup.controls.jiraEmail.value || ''
      }, {
        key: 'jiraProject',
        value: _this5.formGroup.controls.jiraProject.value || 0
      }]);
      _this5.notificationService.success('Jira settings saved');
    })();
  }
  connect() {
    var _this6 = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this6.onSubmit();
      _this6.jiraService.testConnection().subscribe({
        next: () => {
          _this6.notificationService.success('Connection successful');
          _this6.connectionStatus = true;
          _this6.formGroup.get('jiraProject')?.enable();
        },
        error: () => {
          _this6.notificationService.error('Connection failed');
          _this6.connectionStatus = false;
          _this6.formGroup.get('jiraProject')?.disable();
        }
      });
      _this6.jiraProjectService.populate().subscribe({
        next: projects => {
          _this6.jiraProjects = projects[0];
        }
      });
    })();
  }
  formErrors(formControl) {
    return formControl.hasError('required') ? 'You must enter a value' : formControl.hasError('email') ? 'Not a valid email' : formControl.hasError('invalidUrl') ? 'Not a valid URL' : undefined;
  }
  getSelectedProjectParam(projectParam) {
    const selectedProject = this.jiraProjects.find(project => project.id === this.formGroup.controls.jiraProject.value);
    return selectedProject ? selectedProject[projectParam] : undefined;
  }
  static #_ = this.ɵfac = function JiraComponent_Factory(t) {
    return new (t || JiraComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_shared_services_http_setting_service__WEBPACK_IMPORTED_MODULE_2__.SettingService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_shared_services_http_jira_service__WEBPACK_IMPORTED_MODULE_4__.JiraService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_shared_services_http_jira_project_service__WEBPACK_IMPORTED_MODULE_5__.JiraProjectService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_modules_alert_services_notification_service__WEBPACK_IMPORTED_MODULE_3__.NotificationService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: JiraComponent,
    selectors: [["velocap-jira"]],
    decls: 59,
    vars: 17,
    consts: [["mat-card-avatar", "", 1, "jira-header-image"], ["id", "jiraCloud", 3, "formGroup"], [1, "form-fields"], ["appearance", "outline"], ["matInput", "", "placeholder", "Jira URL", "formControlName", "jiraUrl", "id", "jiraUrl"], ["matPrefix", ""], ["matInput", "", "placeholder", "Jira API Token", "formControlName", "jiraToken", "id", "jiraToken", 3, "type"], ["mat-icon-button", "", "matSuffix", "", 3, "click"], ["matInput", "", "placeholder", "Jira Email", "formControlName", "jiraEmail", "type", "email", "id", "jiraEmail"], ["appearance", "outline", "matTooltip", "Connect to select project", 1, "avatar-form-field"], ["width", "24", "height", "24", "alt", "project icon", "class", "avatar-image", 3, "ngSrc", 4, "ngIf"], ["formControlName", "jiraProject", "id", "jiraProject"], [3, "value", 4, "ngFor", "ngForOf"], [1, "form-buttons"], ["type", "submit", "mat-raised-button", "", "color", "primary", "id", "jiraSubmit", 3, "disabled", "click"], ["mat-raised-button", "", "color", "accent", "id", "jiraConnect", 3, "disabled", "click"], ["mat-card-avatar", "", 1, "mat-icon-avatar", 3, "color"], ["width", "24", "height", "24", "alt", "project icon", 1, "avatar-image", 3, "ngSrc"], [3, "value"]],
    template: function JiraComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "mat-card")(1, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4, "Jira Cloud");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "mat-card-subtitle");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, "API Settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "mat-card-content")(8, "form", 1)(9, "div", 2)(10, "mat-form-field", 3)(11, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](12, "Jira URL");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](13, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "mat-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, "link");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "mat-error");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "mat-form-field", 3)(19, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, "Jira API Token");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](21, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](22, "mat-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](23, "vpn_key");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function JiraComponent_Template_button_click_24_listener() {
          return ctx.hideToken = !ctx.hideToken;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](25, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "mat-error");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "mat-form-field", 3)(30, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](31, "Jira Email");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](32, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](33, "mat-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](34, "email");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](35, "mat-error");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](37, "mat-form-field", 9)(38, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](39, "Project");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "mat-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](41, JiraComponent_img_41_Template, 1, 1, "img", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "mat-select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](43, JiraComponent_mat_option_43_Template, 5, 4, "mat-option", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "mat-error");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "div", 13)(47, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function JiraComponent_Template_button_click_47_listener() {
          return ctx.onSubmit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](48, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function JiraComponent_Template_button_click_49_listener() {
          return ctx.connect();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](50, "Connect");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](51, "mat-card")(52, "mat-card-header")(53, "mat-icon", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](54);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](55, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](56);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](57, "mat-card-subtitle");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.formGroup);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.formErrors(ctx.formGroup.controls.jiraUrl));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("type", ctx.hideToken ? "password" : "text");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵattribute"]("aria-label", "Hide password")("aria-pressed", ctx.hideToken);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.hideToken ? "visibility_off" : "visibility");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.formErrors(ctx.formGroup.controls.jiraToken));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.formErrors(ctx.formGroup.controls.jiraEmail));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.formGroup.controls.jiraProject.value && ctx.getSelectedProjectParam("avatarUrl"));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.jiraProjects);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.formErrors(ctx.formGroup.controls.jiraProject));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx.formGroup.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx.formGroup.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("color", ctx.connectionStatus ? "accent" : "warn");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.connectionStatus ? "link" : "link_off", " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.connectionStatus ? "Connected" : "Disconnected");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.connectionStatus ? "Connected to Jira Cloud" : "Check fields and hit connect", " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_material_button__WEBPACK_IMPORTED_MODULE_10__.MatButton, _angular_material_button__WEBPACK_IMPORTED_MODULE_10__.MatIconButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__.MatIcon, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__.MatLabel, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__.MatError, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__.MatPrefix, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__.MatSuffix, _angular_material_select__WEBPACK_IMPORTED_MODULE_13__.MatSelect, _angular_material_core__WEBPACK_IMPORTED_MODULE_14__.MatOption, _angular_material_input__WEBPACK_IMPORTED_MODULE_15__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCard, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCardAvatar, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCardContent, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCardHeader, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCardSubtitle, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCardTitle, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgOptimizedImage, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_17__.MatTooltip],
    styles: ["[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n}\n[_nghost-%COMP%]   mat-card[_ngcontent-%COMP%] {\n  margin-top: 20px;\n  margin-left: 20px;\n  min-width: 550px;\n}\n\n.mat-icon-avatar[_ngcontent-%COMP%] {\n  font-size: 40px;\n}\n\n.jira-header-image[_ngcontent-%COMP%] {\n  background-image: url('jira-logo.png');\n  background-size: cover;\n}\n\n.form-fields[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n}\n.form-fields[_ngcontent-%COMP%]   mat-form-field[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n\n.form-buttons[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n  justify-content: flex-start;\n}\n.form-buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  margin-right: 20px;\n}\n\n.selection-span[_ngcontent-%COMP%] {\n  margin-left: 16px;\n}\n\n.avatar-image[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  margin-right: 10px;\n}\n\nmat-select-trigger[_ngcontent-%COMP%] {\n  display: flex;\n}\nmat-select-trigger[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\nmat-select-trigger[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%], mat-option[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvdmVsb2NhcC9zcmMvYXBwL2ZlYXR1cmVzL3NldHRpbmdzL2ppcmEvamlyYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBQ0Y7QUFDRTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUdBO0VBQ0UsZUFBQTtBQUFGOztBQUdBO0VBQ0Usc0NBQUE7RUFDQSxzQkFBQTtBQUFGOztBQUdBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtBQUFGO0FBRUU7RUFDRSxtQkFBQTtBQUFKOztBQUlBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7QUFERjtBQUdFO0VBQ0Usa0JBQUE7QUFESjs7QUFLQTtFQUNFLGlCQUFBO0FBRkY7O0FBTUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBSEY7O0FBUUE7RUFDRSxhQUFBO0FBTEY7QUFNRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtBQUpKOztBQVFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFMRiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG5cbiAgbWF0LWNhcmQge1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgbWluLXdpZHRoOiA1NTBweDtcbiAgfVxufVxuXG4ubWF0LWljb24tYXZhdGFyIHtcbiAgZm9udC1zaXplOiA0MHB4O1xufVxuXG4uamlyYS1oZWFkZXItaW1hZ2Uge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uLy4uLy4uL2Fzc2V0cy9pbWcvamlyYS1sb2dvLnBuZycpO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4uZm9ybS1maWVsZHMge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICB3aWR0aDogMTAwJTtcblxuICBtYXQtZm9ybS1maWVsZCB7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgfVxufVxuXG4uZm9ybS1idXR0b25zIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuXG4gIGJ1dHRvbiB7XG4gICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xuICB9XG59XG5cbi5zZWxlY3Rpb24tc3BhbiB7XG4gIG1hcmdpbi1sZWZ0OiAxNnB4O1xuXG59XG5cbi5hdmF0YXItaW1hZ2Uge1xuICB3aWR0aDogMjRweDtcbiAgaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cblxuXG5tYXQtc2VsZWN0LXRyaWdnZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBzcGFuIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIH1cbn1cblxubWF0LXNlbGVjdC10cmlnZ2VyIG1hdC1pY29uLCBtYXQtb3B0aW9uIG1hdC1pY29uIHtcbiAgd2lkdGg6IDI0cHg7XG4gIGhlaWdodDogMjRweDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 7380:
/*!**********************************************************************!*\
  !*** ./apps/velocap/src/app/features/settings/settings.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsComponent: () => (/* binding */ SettingsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/tabs */ 989);
/* harmony import */ var _jira_jira_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./jira/jira.component */ 5155);



class SettingsComponent {
  static #_ = this.ɵfac = function SettingsComponent_Factory(t) {
    return new (t || SettingsComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: SettingsComponent,
    selectors: [["velocap-settings"]],
    decls: 7,
    vars: 0,
    consts: [["label", "Jira"], ["label", "Users"], ["label", "E-Days"]],
    template: function SettingsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-tab-group")(1, "mat-tab", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "velocap-jira");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-tab", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-tab", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, " E-Days ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
      }
    },
    dependencies: [_angular_material_tabs__WEBPACK_IMPORTED_MODULE_2__.MatTab, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_2__.MatTabGroup, _jira_jira_component__WEBPACK_IMPORTED_MODULE_0__.JiraComponent],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 3810:
/*!****************************************************************!*\
  !*** ./apps/velocap/src/app/layout/header/header.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeaderComponent: () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var _shared_services_side_nav_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../shared/services/side-nav.service */ 9146);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/toolbar */ 2484);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/button */ 895);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _modules_theme_componenets_theme_picker_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../modules/theme/componenets/theme-picker.component */ 6263);







class HeaderComponent {
  constructor(sideNavService) {
    this.sideNavService = sideNavService;
  }
  toggleSideNav() {
    this.sideNavService.toggle();
  }
  static #_ = this.ɵfac = function HeaderComponent_Factory(t) {
    return new (t || HeaderComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_shared_services_side_nav_service__WEBPACK_IMPORTED_MODULE_0__.SideNavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: HeaderComponent,
    selectors: [["velocap-header"]],
    decls: 10,
    vars: 0,
    consts: [["color", "primary"], ["mat-icon-button", "", "aria-label", "Menu icon", 3, "click"], [1, "flexExpand"], [1, "spacer"]],
    template: function HeaderComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "mat-toolbar", 0)(1, "mat-toolbar-row")(2, "button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function HeaderComponent_Template_button_click_2_listener() {
          return ctx.toggleSideNav();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, "menu");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "VeloCap");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "span", 2)(8, "span", 3)(9, "velocap-theme-picker");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      }
    },
    dependencies: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__.MatToolbar, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__.MatToolbarRow, _angular_material_button__WEBPACK_IMPORTED_MODULE_4__.MatIconButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__.MatIcon, _modules_theme_componenets_theme_picker_component__WEBPACK_IMPORTED_MODULE_1__.ThemePickerComponent],
    styles: ["mat-toolbar[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  z-index: 2;\n}\n\n.spacer[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvdmVsb2NhcC9zcmMvYXBwL2xheW91dC9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLE1BQUE7RUFDQSxVQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxjQUFBO0FBRUYiLCJzb3VyY2VzQ29udGVudCI6WyJtYXQtdG9vbGJhcntcbiAgcG9zaXRpb246Zml4ZWQ7XG4gIHRvcDowO1xuICB6LWluZGV4OiAyO1xufVxuLnNwYWNlciB7XG4gIGZsZXg6IDEgMSBhdXRvO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 381:
/*!******************************************************************!*\
  !*** ./apps/velocap/src/app/layout/sidebar/sidebar.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SidebarComponent: () => (/* binding */ SidebarComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/list */ 3228);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 7947);




const _c0 = () => ["/"];
const _c1 = () => ["/settings"];
class SidebarComponent {
  constructor() {}
  static #_ = this.ɵfac = function SidebarComponent_Factory(t) {
    return new (t || SidebarComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SidebarComponent,
    selectors: [["velocap-sidebar"]],
    decls: 13,
    vars: 4,
    consts: [["mat-list-item", "", 3, "routerLink"], [1, "entry"]],
    template: function SidebarComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-nav-list")(1, "a", 0)(2, "span", 1)(3, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "house");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Dashboard");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "a", 0)(8, "span", 1)(9, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](2, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](3, _c1));
      }
    },
    dependencies: [_angular_material_icon__WEBPACK_IMPORTED_MODULE_1__.MatIcon, _angular_material_list__WEBPACK_IMPORTED_MODULE_2__.MatNavList, _angular_material_list__WEBPACK_IMPORTED_MODULE_2__.MatListItem, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink],
    styles: [".entry[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 1rem;\n  padding: 0.75rem;\n}\n.entry[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  text-decoration: none;\n  color: inherit;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvdmVsb2NhcC9zcmMvYXBwL2xheW91dC9zaWRlYmFyL3NpZGViYXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7QUFDRjtBQUFFO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuZW50cnl7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGdhcDogMXJlbTtcbiAgcGFkZGluZzowLjc1cmVtO1xuICBhIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgY29sb3I6IGluaGVyaXQ7XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 3490:
/*!*********************************************************************************!*\
  !*** ./apps/velocap/src/app/modules/alert/components/notification.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotificationComponent: () => (/* binding */ NotificationComponent)
/* harmony export */ });
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/snack-bar */ 9409);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/button */ 895);





class NotificationComponent {
  constructor(data, snackBarRef) {
    this.data = data;
    this.snackBarRef = snackBarRef;
  }
  dismiss() {
    this.snackBarRef.dismiss();
  }
  static #_ = this.ɵfac = function NotificationComponent_Factory(t) {
    return new (t || NotificationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__.MAT_SNACK_BAR_DATA), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__.MatSnackBarRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: NotificationComponent,
    selectors: [["velocap-notification"]],
    decls: 9,
    vars: 2,
    consts: [[1, "snack-container"], [1, "snack-type"], [3, "fontIcon"], ["mat-icon-button", "", "aria-label", "close", 3, "click"]],
    template: function NotificationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "mat-icon", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div")(4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NotificationComponent_Template_button_click_6_listener() {
          return ctx.dismiss();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "close");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("fontIcon", ctx.data.icon);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.data.message);
      }
    },
    dependencies: [_angular_material_icon__WEBPACK_IMPORTED_MODULE_2__.MatIcon, _angular_material_button__WEBPACK_IMPORTED_MODULE_3__.MatIconButton],
    styles: [".snack-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-start;\n}\n.snack-container[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  margin-right: 10px;\n}\n.snack-container[_ngcontent-%COMP%]   .snack-type[_ngcontent-%COMP%] {\n  margin-top: 5px;\n}\n.snack-container[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  margin-left: auto;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvdmVsb2NhcC9zcmMvYXBwL21vZHVsZXMvYWxlcnQvY29tcG9uZW50cy9ub3RpZmljYXRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtBQUNGO0FBQ0U7RUFDRSxrQkFBQTtBQUNKO0FBQ0U7RUFDRSxlQUFBO0FBQ0o7QUFDRTtFQUNFLGlCQUFBO0FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyIuc25hY2stY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuXG4gID4gZGl2IHtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIH1cbiAgLnNuYWNrLXR5cGUge1xuICAgIG1hcmdpbi10b3A6IDVweDtcbiAgfVxuICBidXR0b24ge1xuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 8049:
/*!*******************************************************************!*\
  !*** ./apps/velocap/src/app/modules/alert/notification.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotificationModule: () => (/* binding */ NotificationModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _components_notification_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/notification.component */ 3490);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/button */ 895);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 1699);





class NotificationModule {
  static #_ = this.ɵfac = function NotificationModule_Factory(t) {
    return new (t || NotificationModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
    type: NotificationModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_4__.MatButtonModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](NotificationModule, {
    declarations: [_components_notification_component__WEBPACK_IMPORTED_MODULE_0__.NotificationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_4__.MatButtonModule]
  });
})();

/***/ }),

/***/ 7751:
/*!*****************************************************************************!*\
  !*** ./apps/velocap/src/app/modules/alert/services/notification.service.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotificationService: () => (/* binding */ NotificationService)
/* harmony export */ });
/* harmony import */ var _shared_services_queue_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/services/queue.service */ 3539);
/* harmony import */ var _components_notification_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/notification.component */ 3490);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/snack-bar */ 9409);





class NotificationService extends _shared_services_queue_service__WEBPACK_IMPORTED_MODULE_0__.QueueService {
  constructor(snackBar) {
    super();
    this.snackBar = snackBar;
  }
  open(message, className, icon) {
    return this.snackBar.openFromComponent(_components_notification_component__WEBPACK_IMPORTED_MODULE_1__.NotificationComponent, {
      data: {
        message,
        action: 'Close',
        icon
      },
      panelClass: [className],
      duration: 2000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom'
    });
  }
  error(message) {
    this.add({
      message,
      className: 'error',
      icon: 'warning'
    });
  }
  success(message) {
    this.add({
      message,
      className: 'success',
      icon: 'check_circle'
    });
  }
  info(message) {
    this.add({
      message,
      className: 'info',
      icon: 'info_circle'
    });
  }
  processItem({
    message,
    className,
    icon
  }, callback) {
    this.open(message, className, icon).afterDismissed().subscribe(callback);
  }
  static #_ = this.ɵfac = function NotificationService_Factory(t) {
    return new (t || NotificationService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__.MatSnackBar));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: NotificationService,
    factory: NotificationService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 6263:
/*!**********************************************************************************!*\
  !*** ./apps/velocap/src/app/modules/theme/componenets/theme-picker.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ThemePickerComponent: () => (/* binding */ ThemePickerComponent)
/* harmony export */ });
/* harmony import */ var _Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _services_style_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/style-manager */ 513);
/* harmony import */ var _services_theme_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/theme-storage */ 6401);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 9736);
/* harmony import */ var _data_theme_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/theme-data */ 4570);
/* harmony import */ var _alert_services_notification_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../alert/services/notification.service */ 7751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/menu */ 8128);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/button */ 895);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/tooltip */ 702);




















function ThemePickerComponent_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ThemePickerComponent_button_5_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r4);
      const theme_r2 = restoredCtx.$implicit;
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r3.selectTheme(theme_r2.name, true));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "mat-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](5, "mat-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const theme_r2 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("docs-theme-selected-icon", ctx_r1.currentTheme === theme_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx_r1.getIconColor(theme_r2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r1.currentTheme === theme_r2 ? "radio_button_checked" : "radio_button_unchecked", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](theme_r2.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"]("theme-example-icon " + theme_r2.name);
  }
}
class ThemePickerComponent {
  constructor(styleManager, themeStorage, activatedRoute, notificationService, iconRegistry, sanitizer) {
    this.styleManager = styleManager;
    this.themeStorage = themeStorage;
    this.activatedRoute = activatedRoute;
    this.notificationService = notificationService;
    this.themes = _data_theme_data__WEBPACK_IMPORTED_MODULE_3__.themes;
    iconRegistry.addSvgIcon('theme-example', sanitizer.bypassSecurityTrustResourceUrl('assets/img/theme-demo-icon.svg'));
  }
  ngOnInit() {
    this.initCurrentTheme();
    this.subscribeToQueryParamChanges();
  }
  ngOnDestroy() {
    this.queryParamSubscription?.unsubscribe();
  }
  selectTheme(themeName, notify) {
    var _this = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const theme = _this.themes.find(t => t.name === themeName);
      if (!theme) return;
      yield _this.applyTheme(theme, notify);
    })();
  }
  initCurrentTheme() {
    const themeName = this.themeStorage.getStoredThemeName() || this.themes.find(t => t.isDefault)?.name;
    themeName && this.selectTheme(themeName, false);
  }
  getIconColor(theme) {
    return this.currentTheme === theme ? 'accent' : undefined;
  }
  subscribeToQueryParamChanges() {
    this.queryParamSubscription = this.activatedRoute.queryParamMap.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(params => params.get('theme'))).subscribe(themeName => {
      themeName && this.selectTheme(themeName, true);
    });
  }
  applyTheme(theme, notify) {
    var _this2 = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.currentTheme = theme;
      _this2.setThemeIfNotDefault(theme);
      notify && _this2.notificationService.success(`${theme.displayName || theme.name} theme selected.`);
      _this2.storeTheme(theme);
    })();
  }
  storeTheme(theme) {
    this.themeStorage.storeTheme(theme);
  }
  setThemeIfNotDefault(theme) {
    theme.isDefault ? this.styleManager.removeStyle('theme') : this.styleManager.setStyle('theme', `${theme.name}.css`);
  }
  static #_ = this.ɵfac = function ThemePickerComponent_Factory(t) {
    return new (t || ThemePickerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_style_manager__WEBPACK_IMPORTED_MODULE_1__.StyleManager), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_theme_storage__WEBPACK_IMPORTED_MODULE_2__.ThemeStorage), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_alert_services_notification_service__WEBPACK_IMPORTED_MODULE_4__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_material_icon__WEBPACK_IMPORTED_MODULE_8__.MatIconRegistry), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__.DomSanitizer));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: ThemePickerComponent,
    selectors: [["velocap-theme-picker"]],
    decls: 6,
    vars: 2,
    consts: [["mat-icon-button", "", "aria-label", "Select a theme", "matTooltip", "Select a theme for the documentation", 3, "mat-menu-trigger-for"], ["xPosition", "before", 1, "docs-theme-picker-menu"], ["themeMenu", "matMenu"], ["mat-menu-item", "", 3, "click", 4, "ngFor", "ngForOf"], ["mat-menu-item", "", 3, "click"], [3, "color"], ["svgIcon", "theme-example"]],
    template: function ThemePickerComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 0)(1, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, "format_color_fill");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "mat-menu", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, ThemePickerComponent_button_5_Template, 6, 7, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("mat-menu-trigger-for", _r0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.themes);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_material_menu__WEBPACK_IMPORTED_MODULE_11__.MatMenu, _angular_material_menu__WEBPACK_IMPORTED_MODULE_11__.MatMenuItem, _angular_material_menu__WEBPACK_IMPORTED_MODULE_11__.MatMenuTrigger, _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__.MatIcon, _angular_material_button__WEBPACK_IMPORTED_MODULE_12__.MatIconButton, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_13__.MatTooltip],
    styles: [".docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon {\n  margin-right: 0;\n  margin-left: auto;\n  padding-left: 8px;\n  order: 1;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon svg {\n  vertical-align: middle;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.deeppurple-amber svg .docs-theme-icon-background {\n  fill: #fafafa;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.deeppurple-amber svg .docs-theme-icon-button {\n  fill: #FFC107;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.deeppurple-amber svg .docs-theme-icon-toolbar {\n  fill: #673AB7;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.indigo-pink svg .docs-theme-icon-background {\n  fill: #fafafa;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.indigo-pink svg .docs-theme-icon-button {\n  fill: #E91E63;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.indigo-pink svg .docs-theme-icon-toolbar {\n  fill: #3F51B5;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.pink-bluegrey svg .docs-theme-icon-background {\n  fill: #303030;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.pink-bluegrey svg .docs-theme-icon-button {\n  fill: #607D8B;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.pink-bluegrey svg .docs-theme-icon-toolbar {\n  fill: #E91E63;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.purple-green svg .docs-theme-icon-background {\n  fill: #303030;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.purple-green svg .docs-theme-icon-button {\n  fill: #4CAF50;\n}\n.docs-theme-picker-menu .mat-mdc-menu-item .mat-icon.theme-example-icon.purple-green svg .docs-theme-icon-toolbar {\n  fill: #9C27B0;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvdmVsb2NhcC9zcmMvYXBwL21vZHVsZXMvdGhlbWUvY29tcG9uZW5ldHMvdGhlbWUtcGlja2VyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxRQUFBO0FBRE47QUFHTTtFQUNFLHNCQUFBO0FBRFI7QUFNUTtFQUNFLGFBQUE7QUFKVjtBQU1RO0VBQ0UsYUFBQTtBQUpWO0FBTVE7RUFDRSxhQUFBO0FBSlY7QUFTUTtFQUNFLGFBQUE7QUFQVjtBQVNRO0VBQ0UsYUFBQTtBQVBWO0FBU1E7RUFDRSxhQUFBO0FBUFY7QUFZUTtFQUNFLGFBQUE7QUFWVjtBQVlRO0VBQ0UsYUFBQTtBQVZWO0FBWVE7RUFDRSxhQUFBO0FBVlY7QUFlUTtFQUNFLGFBQUE7QUFiVjtBQWVRO0VBQ0UsYUFBQTtBQWJWO0FBZVE7RUFDRSxhQUFBO0FBYlYiLCJzb3VyY2VzQ29udGVudCI6WyIuZG9jcy10aGVtZS1waWNrZXItbWVudSB7XG4gIC5tYXQtbWRjLW1lbnUtaXRlbSB7XG4gICAgLm1hdC1pY29uLnRoZW1lLWV4YW1wbGUtaWNvbiB7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDA7XG4gICAgICBtYXJnaW4tbGVmdDogYXV0bztcbiAgICAgIHBhZGRpbmctbGVmdDogOHB4O1xuICAgICAgb3JkZXI6IDE7XG5cbiAgICAgIHN2ZyB7XG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgICB9XG5cbiAgICAgIC8vIFRoZSBiZWxvdyBjb2xvcnMgbmVlZCB0byBhbGlnbiB3aXRoIHRoZSB0aGVtZXMgZGVmaW5lZCBpbiBUaGVtZVBpY2tlclxuICAgICAgJi5kZWVwcHVycGxlLWFtYmVyIHN2ZyB7XG4gICAgICAgIC5kb2NzLXRoZW1lLWljb24tYmFja2dyb3VuZCB7XG4gICAgICAgICAgZmlsbDogI2ZhZmFmYTtcbiAgICAgICAgfVxuICAgICAgICAuZG9jcy10aGVtZS1pY29uLWJ1dHRvbiB7XG4gICAgICAgICAgZmlsbDogI0ZGQzEwNztcbiAgICAgICAgfVxuICAgICAgICAuZG9jcy10aGVtZS1pY29uLXRvb2xiYXIge1xuICAgICAgICAgIGZpbGw6ICM2NzNBQjc7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgJi5pbmRpZ28tcGluayBzdmcge1xuICAgICAgICAuZG9jcy10aGVtZS1pY29uLWJhY2tncm91bmQge1xuICAgICAgICAgIGZpbGw6ICNmYWZhZmE7XG4gICAgICAgIH1cbiAgICAgICAgLmRvY3MtdGhlbWUtaWNvbi1idXR0b24ge1xuICAgICAgICAgIGZpbGw6ICNFOTFFNjM7XG4gICAgICAgIH1cbiAgICAgICAgLmRvY3MtdGhlbWUtaWNvbi10b29sYmFyIHtcbiAgICAgICAgICBmaWxsOiAjM0Y1MUI1O1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgICYucGluay1ibHVlZ3JleSBzdmcge1xuICAgICAgICAuZG9jcy10aGVtZS1pY29uLWJhY2tncm91bmQge1xuICAgICAgICAgIGZpbGw6ICMzMDMwMzA7XG4gICAgICAgIH1cbiAgICAgICAgLmRvY3MtdGhlbWUtaWNvbi1idXR0b24ge1xuICAgICAgICAgIGZpbGw6ICM2MDdEOEI7XG4gICAgICAgIH1cbiAgICAgICAgLmRvY3MtdGhlbWUtaWNvbi10b29sYmFyIHtcbiAgICAgICAgICBmaWxsOiAjRTkxRTYzO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgICYucHVycGxlLWdyZWVuIHN2ZyB7XG4gICAgICAgIC5kb2NzLXRoZW1lLWljb24tYmFja2dyb3VuZCB7XG4gICAgICAgICAgZmlsbDogIzMwMzAzMDtcbiAgICAgICAgfVxuICAgICAgICAuZG9jcy10aGVtZS1pY29uLWJ1dHRvbiB7XG4gICAgICAgICAgZmlsbDogIzRDQUY1MDtcbiAgICAgICAgfVxuICAgICAgICAuZG9jcy10aGVtZS1pY29uLXRvb2xiYXIge1xuICAgICAgICAgIGZpbGw6ICM5QzI3QjA7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
    encapsulation: 2,
    changeDetection: 0
  });
}

/***/ }),

/***/ 4570:
/*!***************************************************************!*\
  !*** ./apps/velocap/src/app/modules/theme/data/theme-data.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   themes: () => (/* binding */ themes)
/* harmony export */ });
const themes = [{
  primary: '#673AB7',
  accent: '#FFC107',
  displayName: 'Deep Purple & Amber',
  name: 'deeppurple-amber',
  isDark: false
}, {
  primary: '#3F51B5',
  accent: '#E91E63',
  displayName: 'Indigo & Pink',
  name: 'indigo-pink',
  isDark: false,
  isDefault: true
}, {
  primary: '#E91E63',
  accent: '#607D8B',
  displayName: 'Pink & Blue-grey',
  name: 'pink-bluegrey',
  isDark: true
}, {
  primary: '#9C27B0',
  accent: '#4CAF50',
  displayName: 'Purple & Green',
  name: 'purple-green',
  isDark: true
}];

/***/ }),

/***/ 513:
/*!**********************************************************************!*\
  !*** ./apps/velocap/src/app/modules/theme/services/style-manager.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StyleManager: () => (/* binding */ StyleManager)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);

class StyleManager {
  setStyle(key, href) {
    this.getLinkElementForKey(key).setAttribute('href', href);
  }
  removeStyle(key) {
    const existingLinkElement = this.getExistingLinkElementByKey(key);
    existingLinkElement && document.head.removeChild(existingLinkElement);
  }
  getLinkElementForKey(key) {
    return this.getExistingLinkElementByKey(key) || this.setLinkElement(this.createLinkElementWithKey(key));
  }
  getExistingLinkElementByKey(key) {
    return document.head.querySelector(`link[rel="stylesheet"].${this.getClassNameForKey(key)}`);
  }
  setLinkElement(linkEl) {
    return document.head.appendChild(linkEl);
  }
  createLinkElementWithKey(key) {
    return Object.assign(document.createElement('link'), {
      rel: 'stylesheet',
      classList: [this.getClassNameForKey(key)]
    });
  }
  getClassNameForKey(key) {
    return `style-manager-${key}`;
  }
  static #_ = this.ɵfac = function StyleManager_Factory(t) {
    return new (t || StyleManager)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
    token: StyleManager,
    factory: StyleManager.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 6401:
/*!**********************************************************************!*\
  !*** ./apps/velocap/src/app/modules/theme/services/theme-storage.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ThemeStorage: () => (/* binding */ ThemeStorage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _data_theme_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../data/theme-data */ 4570);



class ThemeStorage {
  constructor() {
    this.onThemeUpdate = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
  }
  static #_ = this.storageKey = 'docs-theme-storage-current-name';
  getCurrentTheme() {
    const themeName = this.getStoredThemeName();
    return themeName ? this.getTheme(themeName) : undefined;
  }
  getTheme(name) {
    return _data_theme_data__WEBPACK_IMPORTED_MODULE_0__.themes.find(t => t.name === name);
  }
  storeTheme(theme) {
    try {
      window.localStorage[ThemeStorage.storageKey] = theme.name;
    } catch {}
    document.documentElement.style.setProperty('--primary-color', theme.primary);
    document.documentElement.style.setProperty('--accent-color', theme.accent);
    this.onThemeUpdate.emit(theme);
  }
  getStoredThemeName() {
    try {
      return window.localStorage[ThemeStorage.storageKey] || null;
    } catch {
      return null;
    }
  }
  clearStorage() {
    try {
      window.localStorage.removeItem(ThemeStorage.storageKey);
    } catch {}
  }
  static #_2 = this.ɵfac = function ThemeStorage_Factory(t) {
    return new (t || ThemeStorage)();
  };
  static #_3 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: ThemeStorage,
    factory: ThemeStorage.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 3079:
/*!************************************************************!*\
  !*** ./apps/velocap/src/app/modules/theme/theme.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ThemeModule: () => (/* binding */ ThemeModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _componenets_theme_picker_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./componenets/theme-picker.component */ 6263);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/menu */ 8128);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/button */ 895);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/tooltip */ 702);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 1699);







class ThemeModule {
  static #_ = this.ɵfac = function ThemeModule_Factory(t) {
    return new (t || ThemeModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
    type: ThemeModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_material_menu__WEBPACK_IMPORTED_MODULE_3__.MatMenuModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_5__.MatButtonModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__.MatTooltipModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](ThemeModule, {
    declarations: [_componenets_theme_picker_component__WEBPACK_IMPORTED_MODULE_0__.ThemePickerComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_material_menu__WEBPACK_IMPORTED_MODULE_3__.MatMenuModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_5__.MatButtonModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__.MatTooltipModule],
    exports: [_componenets_theme_picker_component__WEBPACK_IMPORTED_MODULE_0__.ThemePickerComponent]
  });
})();

/***/ }),

/***/ 1578:
/*!*****************************************************************************************!*\
  !*** ./apps/velocap/src/app/shared/components/custom-banner/custom-banner.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CustomBannerComponent: () => (/* binding */ CustomBannerComponent)
/* harmony export */ });
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/card */ 8497);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/icon */ 6515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);






function CustomBannerComponent_mat_card_content_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card-content")(1, "div", 3)(2, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.content, " ");
  }
}
function CustomBannerComponent_mat_card_actions_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "mat-card-actions", 4);
  }
}
class CustomBannerComponent {
  static #_ = this.ɵfac = function CustomBannerComponent_Factory(t) {
    return new (t || CustomBannerComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: CustomBannerComponent,
    selectors: [["velocap-app-custom-banner"]],
    inputs: {
      title: "title",
      subtitle: "subtitle",
      icon: "icon",
      content: "content",
      actions: "actions"
    },
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵStandaloneFeature"]],
    decls: 3,
    vars: 2,
    consts: [[1, "custom-banner"], [4, "ngIf"], ["align", "end", 4, "ngIf"], ["mat-card-avatar", ""], ["align", "end"]],
    template: function CustomBannerComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, CustomBannerComponent_mat_card_content_1_Template, 5, 2, "mat-card-content", 1)(2, CustomBannerComponent_mat_card_actions_2_Template, 1, 0, "mat-card-actions", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.content);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.actions);
      }
    },
    dependencies: [_angular_material_card__WEBPACK_IMPORTED_MODULE_1__.MatCardModule, _angular_material_card__WEBPACK_IMPORTED_MODULE_1__.MatCard, _angular_material_card__WEBPACK_IMPORTED_MODULE_1__.MatCardActions, _angular_material_card__WEBPACK_IMPORTED_MODULE_1__.MatCardAvatar, _angular_material_card__WEBPACK_IMPORTED_MODULE_1__.MatCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIcon],
    styles: [".custom-banner[_ngcontent-%COMP%] {\n  border: 2px solid var(--primary-color);\n  border-radius: 4px;\n  margin: 0 0 20px 0;\n  padding: 0;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvdmVsb2NhcC9zcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2N1c3RvbS1iYW5uZXIvY3VzdG9tLWJhbm5lci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLHNDQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFBRiIsInNvdXJjZXNDb250ZW50IjpbIlxuLmN1c3RvbS1iYW5uZXIge1xuICBib3JkZXI6IDJweCBzb2xpZCB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBtYXJnaW46IDAgMCAyMHB4IDA7XG4gIHBhZGRpbmc6IDA7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 6827:
/*!**********************************************************************!*\
  !*** ./apps/velocap/src/app/shared/services/abstractHttp.service.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AbstractHttpService: () => (/* binding */ AbstractHttpService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 2389);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 3252);
/* harmony import */ var _modules_alert_services_notification_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../modules/alert/services/notification.service */ 7751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 4860);






class AbstractHttpService {
  constructor(httpClient, notificationService) {
    this.httpClient = httpClient;
    this.notificationService = notificationService;
    this.APIUrl = 'http://localhost:3000/api' + this.getResourceUrl();
  }
  toServerModel(entity) {
    return entity;
  }
  fromServerModel(json) {
    return json;
  }
  getAll() {
    return this.httpClient.get(this.APIUrl).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)));
  }
  get(id) {
    return this.httpClient.get(`${this.APIUrl}/${id}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)));
  }
  insert(entity) {
    return this.httpClient.post(this.APIUrl, entity).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)));
  }
  handleError(error) {
    this.notificationService.error(error.message);
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.throwError)(() => new Error(error.message || 'Server error'));
  }
  static #_ = this.ɵfac = function AbstractHttpService_Factory(t) {
    return new (t || AbstractHttpService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_modules_alert_services_notification_service__WEBPACK_IMPORTED_MODULE_0__.NotificationService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
    token: AbstractHttpService,
    factory: AbstractHttpService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 9795:
/*!***************************************************************************!*\
  !*** ./apps/velocap/src/app/shared/services/http/jira-project.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JiraProjectService: () => (/* binding */ JiraProjectService)
/* harmony export */ });
/* harmony import */ var _abstractHttp_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../abstractHttp.service */ 6827);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 1699);


class JiraProjectService extends _abstractHttp_service__WEBPACK_IMPORTED_MODULE_0__.AbstractHttpService {
  getResourceUrl() {
    return '/jira-project';
  }
  getProjects() {
    return this.httpClient.get(`${this.APIUrl}`);
  }
  populate() {
    return this.httpClient.get(`${this.APIUrl}/populate`);
  }
  static #_ = this.ɵfac = /*@__PURE__*/(() => {
    let ɵJiraProjectService_BaseFactory;
    return function JiraProjectService_Factory(t) {
      return (ɵJiraProjectService_BaseFactory || (ɵJiraProjectService_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](JiraProjectService)))(t || JiraProjectService);
    };
  })();
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: JiraProjectService,
    factory: JiraProjectService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 1758:
/*!*******************************************************************!*\
  !*** ./apps/velocap/src/app/shared/services/http/jira.service.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JiraService: () => (/* binding */ JiraService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 4860);



class JiraService {
  constructor(httpClient) {
    this.httpClient = httpClient;
    this.APIUrl = 'http://localhost:3000/api/jira';
  }
  testConnection() {
    return this.httpClient.get(`${this.APIUrl}/test`);
  }
  static #_ = this.ɵfac = function JiraService_Factory(t) {
    return new (t || JiraService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
    token: JiraService,
    factory: JiraService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 7904:
/*!**********************************************************************!*\
  !*** ./apps/velocap/src/app/shared/services/http/setting.service.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingService: () => (/* binding */ SettingService)
/* harmony export */ });
/* harmony import */ var _Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _abstractHttp_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../abstractHttp.service */ 6827);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 1236);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);




class SettingService extends _abstractHttp_service__WEBPACK_IMPORTED_MODULE_1__.AbstractHttpService {
  getResourceUrl() {
    return '/setting';
  }
  getByKey(key) {
    return this.httpClient.get(`${this.APIUrl}/key/${key}`);
  }
  getByKeys(keys) {
    return this.httpClient.get(`${this.APIUrl}/keys`, {
      params: {
        keys
      }
    });
  }
  updateByKey(key, value) {
    var _this = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.lastValueFrom)(_this.httpClient.put(`${_this.APIUrl}/key/${key}`, {
        value
      }));
    })();
  }
  updateByKeys(settings) {
    var _this2 = this;
    return (0,_Users_adamlewis_Repos_velocap_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.lastValueFrom)(_this2.httpClient.put(`${_this2.APIUrl}/keys`, {
        settings
      }));
    })();
  }
  static #_ = this.ɵfac = /*@__PURE__*/(() => {
    let ɵSettingService_BaseFactory;
    return function SettingService_Factory(t) {
      return (ɵSettingService_BaseFactory || (ɵSettingService_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetInheritedFactory"](SettingService)))(t || SettingService);
    };
  })();
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
    token: SettingService,
    factory: SettingService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 3539:
/*!***************************************************************!*\
  !*** ./apps/velocap/src/app/shared/services/queue.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   QueueService: () => (/* binding */ QueueService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);

class QueueService {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
  }
  add(item) {
    this.queue.push(item);
    !this.isProcessing && this.processQueue();
  }
  processQueue() {
    if (!this.queue.length) {
      this.isProcessing = false;
      return;
    }
    this.isProcessing = true;
    const item = this.queue.shift();
    if (!item) {
      this.isProcessing = false;
      return;
    }
    this.processItem(item, () => {
      this.processQueue();
    });
  }
  static #_ = this.ɵfac = function QueueService_Factory(t) {
    return new (t || QueueService)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
    token: QueueService,
    factory: QueueService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 9146:
/*!******************************************************************!*\
  !*** ./apps/velocap/src/app/shared/services/side-nav.service.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SideNavService: () => (/* binding */ SideNavService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 8071);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 1699);


class SideNavService {
  constructor() {
    this.toggleBehaviour = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(true);
  }
  toggle() {
    this.toggleBehaviour.next(!this.toggleBehaviour.getValue());
  }
  static #_ = this.ɵfac = function SideNavService_Factory(t) {
    return new (t || SideNavService)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: SideNavService,
    factory: SideNavService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 7508:
/*!*******************************************************!*\
  !*** ./apps/velocap/src/app/shared/validators/url.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UrlValidator: () => (/* binding */ UrlValidator)
/* harmony export */ });
class UrlValidator {
  static validate(control) {
    const url = control.value;
    if (!url) return null;
    const regex = new RegExp('^(https?://)?(www.)?' + '[a-zA-Z0-9@:%._\\+~#?&//=]' + '{2,256}\\.[a-z]' + '{2,6}\\b([-a-zA-Z0-9@:%' + '._\\+~#?&//=]*)');
    return regex.test(url) ? null : {
      invalidUrl: true
    };
  }
}

/***/ }),

/***/ 9988:
/*!**********************************!*\
  !*** ./apps/velocap/src/main.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 3760);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(9548), __webpack_exec__(9988)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map